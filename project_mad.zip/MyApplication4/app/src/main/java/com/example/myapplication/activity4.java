package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class activity4 extends AppCompatActivity {


    private RecyclerView myRecycleView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity4);

        myRecycleView =(RecyclerView) findViewById(R.id.recyclerView);
        myRecycleView.setHasFixedSize(true);
        myRecycleView.setLayoutManager(new LinearLayoutManager(this));

        listItems = new ArrayList<>();


        Bundle dataFromFirst=getIntent().getExtras();
        TextView mytext= findViewById(R.id.d1);
        mytext.setText("");
        if(dataFromFirst==null)
        {
            return;
        }
        String n=dataFromFirst.getString("message");

        SharedPreferences sharedpref = getSharedPreferences("patientinfo", Context.MODE_PRIVATE);
        int num=sharedpref.getInt("count",0);
        for (int i = 0; i < num; i++) {


            String rname = sharedpref.getString("username" + i, "");
            if (n.equals(rname)) {
                String na,e,a,h,g,t;
                int number;
                na=sharedpref.getString("username"+i ,"");
                e=sharedpref.getString("Email"+i,"");
                a=sharedpref.getString("Address"+i,"");
                g=sharedpref.getString("Gender"+i,"");
                number=sharedpref.getInt("myint"+i,0);
                mytext.setText("Personal Data:-\nName : "+na+"\n"+" Email : "+e+"\n"+"Address : "+a+"\n"+"Gender :"+g+"\n"+"Number : "+number+"\n");
                break;
            }
            displaydoctor();
        }
    }
    void displaydoctor()
    {
        SharedPreferences sharedpref1 = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        int num1=sharedpref1.getInt("count",0);


        for (int i = 0; i < num1; i++) {
            String na,e,a,h,g,t;
            int number;
            na=sharedpref1.getString("username"+i ,"");
            number=sharedpref1.getInt("myint"+i,0);
            e=sharedpref1.getString("Email"+i,"");
            h=sharedpref1.getString("Hospital"+i,"");
            a=sharedpref1.getString("Address"+i,"");
            t=sharedpref1.getString("Timing"+i,"");
            g=sharedpref1.getString("Gender"+i,"");

            ListItem listitem =new ListItem("Doctor " + (i+1) + "\nName: " + na + "\nEmail: " + e + "\nAddress: " + a + "\nGender: " + g + "\nPhone Number: " + number + "\nHospital: " + h + "\nTiming: " + t);
            listItems.add(listitem);
        }
        adapter = new myadaptor (this,listItems);
        myRecycleView.setAdapter(adapter);
    }


}

package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Integer.parseInt;

public class activity8 extends AppCompatActivity {

    EditText usernameinput;
    EditText passwordinput;
    EditText pass2input;
    EditText numberinput;
    EditText email;
    EditText address;
    RadioGroup rg;
    int c1=0;
    TextView em,pa,in;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity8);
        usernameinput=findViewById(R.id.editText);
        passwordinput=findViewById(R.id.editText14);
        numberinput=findViewById(R.id.editText2);
        email=findViewById(R.id.editText3);
        address=findViewById(R.id.editText4);
        rg=findViewById(R.id.radioGroup);
        pass2input=findViewById(R.id.editText5);
        em=findViewById(R.id.textView9);
        pa=findViewById(R.id.textView4);
        in=findViewById(R.id.textView8);
    }
    public void saveinfo(View view) {
        in.setText("");
        pa.setText("");
        em.setText("");
        SharedPreferences shared = getSharedPreferences("patientinfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor1 = shared.edit();
        int num1=shared.getInt("count",0);
        c1=num1;
        String u,p,e,a,g,p2;
        int m;
        u=usernameinput.getText().toString();
        p=passwordinput.getText().toString();
        e=email.getText().toString();
        a=address.getText().toString();
        g=((RadioButton)findViewById(rg.getCheckedRadioButtonId())).getText().toString();
        m=Integer.parseInt(numberinput.getText().toString());
        p2=pass2input.getText().toString();
       if(u.length() == 0 || p.length() == 0 || e.length() == 0 || a.length() == 0 || g.length() == 0 || p2.length()==0)
        {
            in.setText("Input all fields");
            in.setTextColor(Color.RED);

        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(e).matches())
       {
           em.setText("Email is not valid");
           em.setTextColor(Color.RED);
       }
        else
        {
            if (p2.equals(p)) {
                editor1.putString("username" + c1, u);
                editor1.putString("password" + c1, p);
                editor1.putInt("myint" + c1, m);
                editor1.putString("Email" + c1, e);
                editor1.putString("Address" + c1, a);
                editor1.putString("Gender" + c1, g);
                c1++;
                editor1.putInt("count", parseInt(String.valueOf(c1)));
                editor1.apply();
                Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(this, Activity5.class);
                startActivity(i);
            } else
            {
                pa.setText("Passwords are not same.");
                pa.setTextColor(Color.RED);
            }
        }
    }

}

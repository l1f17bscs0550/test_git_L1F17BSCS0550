package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class activity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity4);

        Bundle dataFromFirst=getIntent().getExtras();
        TextView mytext= findViewById(R.id.d1);
        mytext.setText("");
        if(dataFromFirst==null)
        {
            return;
        }
        String n=dataFromFirst.getString("message");

        SharedPreferences sharedpref = getSharedPreferences("patientinfo", Context.MODE_PRIVATE);
        int num=sharedpref.getInt("count",0);
        for (int i = 0; i < num; i++) {


            String rname = sharedpref.getString("username" + i, "");
            if (n.equals(rname)) {
                String na,e,a,h,g,t;
                int number;
                na=sharedpref.getString("username"+i ,"");
                e=sharedpref.getString("Email"+i,"");
                a=sharedpref.getString("Address"+i,"");
                g=sharedpref.getString("Gender"+i,"");
                number=sharedpref.getInt("myint"+i,0);
                mytext.setText("Personal Data\nName : "+na+"\n"+" Email : "+e+"\n"+"Address : "+a+"\n"+"Gender :"+g+"\n"+"Number : "+number+"\n");
                break;
            }
        }

    }
}

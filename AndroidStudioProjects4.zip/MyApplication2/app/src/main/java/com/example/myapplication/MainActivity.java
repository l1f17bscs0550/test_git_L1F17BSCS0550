package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Placeholder;

import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class MainActivity extends AppCompatActivity {

    ConstraintLayout layout;
    Placeholder placeholder;
    boolean a=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout=findViewById(R.id.Thelayout);
        placeholder=findViewById(R.id.placeholder);
    }
    public void moveButton(View v) {
        if (a==false) {
            Animation zoomAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            v.startAnimation(zoomAnim);
            zoomAnim.setFillEnabled(true);
            zoomAnim.setFillAfter(true);
            TransitionManager.beginDelayedTransition(layout);
            placeholder.setContentId(v.getId());
            a=true;
        }
        else
        {
            Animation zoomAnim1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_out);
            v.startAnimation(zoomAnim1);
            zoomAnim1.setFillEnabled(true);
            zoomAnim1.setFillAfter(true);
            TransitionManager.beginDelayedTransition(layout);
            placeholder.setEmptyVisibility (0);
            a=false;
        }
    }
}

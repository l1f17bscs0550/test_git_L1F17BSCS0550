package database.example.assignment_alertdialoge;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
//public Button b;

Button show,hello,close;
    Dialog MyDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        show= (Button) findViewById(R.id.show);
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mycustomalertdialog();
            }
        });
    }
    public void mycustomalertdialog(){
        MyDialog=new Dialog(MainActivity.this);
        MyDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        MyDialog.setContentView(R.layout.customdialog);
        MyDialog.setTitle("My Custom Dialog");

        hello=(Button)MyDialog.findViewById(R.id.hello);
        close=(Button)MyDialog.findViewById(R.id.close);

        hello.setEnabled(true);
        close.setEnabled(true);

        hello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Hello, I'm Custom Alert Dialog", Toast.LENGTH_SHORT).show();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDialog.cancel();
            }
        });

        MyDialog.show();
    }

}



     /*  b= (Button) findViewById(R.id.button2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
     //           openDialog();         //simple one  just create dialog class


            /*     //Custom alertdialog

               AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this); //for custom dialog create new layout file
                View mView =getLayoutInflater().inflate(R.layout.dialog_login,null);
               final EditText em = (EditText) mView.findViewById(R.id.editText);
               final EditText ep = (EditText) mView.findViewById(R.id.editText2);
                Button eb = (Button) mView.findViewById(R.id.button);

                eb.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!em.getText().toString().isEmpty() && !ep.getText().toString().isEmpty())
                        {
                            Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this, "Login error", Toast.LENGTH_SHORT).show();
                        }

                    }
                });

/*                builder.setView(mView);
                AlertDialog dialog=builder.create();
                dialog.show();
           }
        });
    }
    /*public void openDialog()  //simple
    {
        Dialog dialog =new Dialog();
        dialog.show(getSupportFragmentManager(),"dialog");
    }


    */
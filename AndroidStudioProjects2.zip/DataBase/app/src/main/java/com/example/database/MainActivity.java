package com.example.database;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SQLiteHelper mydatabase;
    EditText editname, editfaculty, editcourse, Id,semester;
    EditText mad,os,oop,dues;
    Button btnAdd, btnView, btnUpdate, btnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mydatabase = new SQLiteHelper(this);
        editname = findViewById(R.id.editText);
        editfaculty = findViewById(R.id.editText2);
        Id = findViewById(R.id.editText4);
        semester = findViewById(R.id.editText6);
        editcourse = findViewById(R.id.editText3);
        btnAdd = findViewById(R.id.button);
        btnUpdate = findViewById(R.id.button3);
        btnView = findViewById(R.id.button2);
        btnDelete = findViewById(R.id.button4);
//table 2
        mad = findViewById(R.id.editText9);
        os = findViewById(R.id.editText7);
        oop = findViewById(R.id.editText8);
        dues = findViewById(R.id.editText5);
    }

    public void Add_data(View view) {
        boolean isInserted = mydatabase.insertData(
//table 1
                editname.getText().toString(),
                editfaculty.getText().toString(),
                editcourse.getText().toString(),
                semester.getText().toString(),

                //table 2

                Integer.parseInt( mad.getText().toString()),
                Integer.parseInt( os.getText().toString() ),
                Integer.parseInt( oop.getText().toString() ),
                Integer.parseInt( dues.getText().toString() )

        );
        if (isInserted == true) {
            Toast.makeText(MainActivity.this, "Data Inserterd", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Data not Inserterd", Toast.LENGTH_SHORT).show();
        }
    }

    public void View_data(View view) {

            Cursor res = mydatabase.getAllData();
        if (res.getCount() == 0 ) {
            showMessage("Error", "Nothing Found");
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append("RollNumber: " + res.getString(0) + "\n");
            buffer.append("Mad " + res.getString(1) + "\n");
            buffer.append("Os: " + res.getString(2) + "\n");
            buffer.append("Oop: " + res.getString(3) + "\n");
            buffer.append("Dues: " + res.getString(4) + "\n");
            buffer.append("Faculty: " + res.getString(5) + "\n\n");;

        }
        showMessage("Data", buffer.toString());
    }

    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void UpdateData() {
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = mydatabase.updateData(
                        Id.getText().toString(),
                        editname.getText().toString(),
                        editfaculty.getText().toString(),
                        editcourse.getText().toString(),
                semester.getText().toString());

                if (isInserted == true) {
                    Toast.makeText(MainActivity.this, "Data Updated", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Data Not Updated", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void deleteData() {
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Integer deletedRows=myDatabase.deleteData(editId.getText().toString());
                if(deletedRows>0)
                {
                    Toast.makeText(MainActivity.this, "Data Deleted", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(MainActivity.this,"Data Not Deleted",Toast.LENGTH_LONG).show();
                } */
            }
        });
    }
}

package com.example.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {

    public static final String databaseName="Student.db";
    public static final String tableName="basicInfo";
    public static final String Col1="RollNumber";
    public static final String Col2="Name";
    public static final String Col3="Faculty";
    public static final String Col4="Course";
    public static final String Col5="Semester";

    //table 2

    public static final String tableName1="attndnc";
    public static final String col1="RollNumber";
    public static final String col2="Mad";
    public static final String col3="Os";
    public static final String col4="Oop";
    public static final String col5="Dues";
    public static final String col6="Faculty";

    public SQLiteHelper(Context context) {
        super(context, databaseName, null, 2);
        SQLiteDatabase db=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//create table 1
        String SQLString="create table " + tableName +
                "("
                + Col1 + " Integer Primary Key Autoincrement, "
                + Col2 + " Text, "
                + Col3 + " Text, "
                + Col4 + " Text,"
                + Col5 + " Text" +
                ")";
        db.execSQL(SQLString);
//create table 2
        String SQLString1="create table " + tableName1 +
                "("
                + col1 + " Integer Primary Key Autoincrement, "
                + col2 + " Integer, "
                + col3 + " Integer, "
                + col4 + " Integer, "
                + col5 + " Integer, "
                + col6 + " String "+
                ")";

        db.execSQL(SQLString1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
         //upgrade tables
        db.execSQL("drop table if exists "+tableName);
        db.execSQL("drop table if exists "+tableName1);
        onCreate(db);

    }
    public boolean insertData (String name, String faculty, String course, String semester, Integer mad ,  Integer os,  Integer oop ,  Integer dues)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        //table 1
        ContentValues ourContent=new ContentValues();
        ourContent.put(Col2, name);
        ourContent.put(Col3, faculty);
        ourContent.put(Col4, course);
        ourContent.put(Col5, semester);
        long result=db.insert(tableName,null,ourContent);
//table 2

        ourContent.put(col2, mad);
        ourContent.put(col3, os);
        ourContent.put(col4, oop);
        ourContent.put(col5, dues);
        ourContent.put(col6, faculty);
        long result1=db.insert(tableName1,null,ourContent);


        if(result==-1 && result1==-1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    public Cursor getAllData()
    {
        SQLiteDatabase db=this.getWritableDatabase();

        //Cursor result=db.rawQuery("select * from " +tableName1,null);
        Cursor result=db.rawQuery("select faculty, os from attndnc where faculty=? and os> ?",new String[]{"Foit" , "20"});
        return result;
        //db.rawQuery("select id, name from people where name=? and id=?",new String[]{"David", "3"});

    }


    public boolean updateData(String id,String name,String faculty,String course,String semester)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues forUpdate=new ContentValues();
        forUpdate.put(Col1,id);
        forUpdate.put(Col2,name);
        forUpdate.put(Col3,faculty);
        forUpdate.put(Col4,course);
        forUpdate.put(Col5,semester);
        db.update(tableName,forUpdate,"RollNumber = ?",new String[]{id});
/*
        forUpdate.put(col1,id);
        forUpdate.put(col2,quiz);
        forUpdate.put(col3,assignment);
        db.update(tableName1,forUpdate,"RollNumber = ?",new String[]{id});
 */

        return true;
    }

    public Integer deleteData(String id)
    {
        SQLiteDatabase db =this.getWritableDatabase();
        return db.delete(tableName,"RollNumber = ?",new String[]{id});
    }

}

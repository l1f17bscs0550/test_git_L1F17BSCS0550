package com.example.recycleview;

import android.app.LauncherActivity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class myadaptor extends RecyclerView.Adapter<myadaptor.ViewHolder> {
    private Context context;
    private List<listItem> listItems;
}

@Override
public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View v = LayoutInflater.from (parent.getContext()). inflate(R.layout.llist_row,parent,false);

    return new ViewHolder(v,context,(ArrayList<listItem>)listItems);
}

@Override
public void onBindViewHolder(ViewHolder holder, int position) {
    listItem listitem = listItems.get(position);
    holder.name.setText(listitem.getName());
    holder.description.setText(listitem.getDescription());
}

@Override
public int getItemCount() {
    return listItems.size();
}

public class ViewHolder extends RecyclerView.ViewHolder implements  View.OnClickListener {
    public TextView name;
    public TextView description;

    public ViewHolder(View view, Context ctx, ArrayList<listItem> items) {
        super(view);
        listItem = items;

        context ctx;
        view.setOnClickListener(this);

        name = (TextView) view.findViewById(R.id.title);
        description = (TextView) view.findViewById(R.id.description);
    }
@Override
    public void onClick(View v){
        int position = getAdapterPosition();
        listItem item =listItems.get(position);

    Toast.makeText(context,item.getName(),Toast.LENGTH_LONG).show();

}
}
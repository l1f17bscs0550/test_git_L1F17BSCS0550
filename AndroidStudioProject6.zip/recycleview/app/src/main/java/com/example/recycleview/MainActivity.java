package com.example.recycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.LauncherActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView myRecycleView;
    private RecyclerView.Adapter adapter;
    private List<listItem> listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myRecycleView =(RecyclerView) findViewById(R.id.recyclerView);
        myRecycleView.setHasFixedSize(true);
        myRecycleView.setLayoutManager(new LinearLayoutManager(this));

        listItems = new ArrayList<>();

        for(int i=0;i<10;i++)
        {
            listItem listitem =new listItem("Item "+(i+1),"Description");
        }

        listItems.add(listitem);
    }

    adapter = new myadaptor (this,listItems);
    myRecyclerView.setAdapter(adapter);
}

package com.example.recycleview;

import android.app.LauncherActivity;

public class listItem {
    private String name;
    private String description;

    public listItem(String name,String description)
    {
        this.name =name;
        this.description =description;
    }
    public String getName(){return  name;}

    public void setName(String n){this.name=n;}

    public String getDescription(){return description;}

    public void setDescription(String d){ this.description=d;}
}

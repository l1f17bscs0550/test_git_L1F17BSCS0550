package database.example.database_lec;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SQLiteHelper myDatabase;
    EditText editName,editFaculty,editCourse;
    Button btnAdd,btnView,btnUpdate,btnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDatabase= new SQLiteHelper(this);
        editName=findViewById(R.id.firstname);
        editFaculty=findViewById(R.id.faculty);
        editCourse=findViewById(R.id.course) ;
        btnAdd=findViewById(R.id.add);
        btnUpdate=findViewById(R.id.update);
        btnView=findViewById(R.id.Read);
        btnDelete=findViewById(R.id.Delete);
        myDatabase = new SQLiteHelper(this);
    }

    public void AddData()
    {
        btnAdd.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDatabase.insertData(editName.getText().toString(), editFaculty.getText().toString(), editCourse.getText().toString());
                        if(isInserted==true) {
                            Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this, "Data not inserted", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
    }

    public void ViewAll() {
        btnView.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick (View v){
                        Cursor res =myDatabase.getAllData();

                        if(res.getCount()==0) {
                            showMessage("Error","Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while(res.moveToNext()){
                            buffer.append("RollNumber: " + res.getString(0) + "\n");
                            buffer.append("Name: " + res.getString(1) + "\n");
                            buffer.append("Faculty: " + res.getString(2) + "\n");
                            buffer.append("Course: " + res.getString(3) + "\n\n");
                        }
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

}

// data -> data -> project folder -> student.db isy agr dekhna h to dono files ko select kr ky save
// as kr ky kahi bhi save kr lo or phir db browser kholo gy or file select kro gy to yay show kr dy ga.
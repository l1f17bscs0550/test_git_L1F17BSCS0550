package database.example.database_lec;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {


    public static final String databaseName ="student.db";
    public static final String tableName ="BasicInfo";
    public static final String Col1 ="RollNumber";
    public static final String Col2 ="Name";
    public static final String Col3 ="Faculty";
    public static final String Col4="Course";

    public SQLiteHelper(@Nullable Context context) {
        super(context,databaseName, null, 1);  //1 oncreate 2 onupgrade
        SQLiteDatabase db=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String SQLString = "create table " + tableName + "("
                + Col1 + " Integer Primary Key Autoincrement, "
                + Col2 + " Text, "
                + Col3 + " Text, "
                + Col4 + " Text "
                + ")" ;

        db.execSQL(SQLString);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists "+tableName);
        onCreate(db);
    }

    public boolean insertData (String name, String faculty, String course) {
        SQLiteDatabase db =this.getWritableDatabase();
        ContentValues ourContent =new ContentValues();

        ourContent.put(Col2, name);
        ourContent.put(Col3, faculty);
        ourContent.put(Col4, course);

        long result = db.insert(tableName,null,ourContent);   //db.insert built-in function h 2 parameter means empty row create ni krny data android studio mein is null ka mtlb h jb tmhy sb kuch empty mil jy to null rkhwa do. yay ak row create kr dy ga or us mein null ho ga.

        if(result==-1)
            return false;

        else
            return true;
    }

    public Cursor getAllData(){
        SQLiteDatabase db =this.getWritableDatabase();
        Cursor result = db.rawQuery("select * from " +tableName, null);

        return result;

        //    db.rawQuery("select id, name from people where name = ? and id = ?", new String()("David","3"));


    }

    public boolean updateData(String id, String name, String faculty, String course){
        SQLiteDatabase db =this.getWritableDatabase();

        ContentValues forUpdate = new ContentValues();
        forUpdate.put(Col2, name);
        forUpdate.put(Col3, faculty);
        forUpdate.put(Col4, course);

        db.update(tableName,forUpdate,"Roll Number = ?",new String[]{id});
        return true;
    }

    //db.update(tableName,contentValues,"ID = ?",new String[]{id});

}

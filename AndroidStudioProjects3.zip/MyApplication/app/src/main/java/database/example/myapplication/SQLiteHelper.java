package database.example.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {


    public static final String databaseName ="student.db";
    public static final String tableName ="BasicInfo";
    public static final String Col1 ="RollNumber";
    public static final String Col2 ="Name";
    public static final String Col3 ="Faculty";
    public static final String Col4="Course";

    public SQLiteHelper(@Nullable Context context) {
        super(context,databaseName, null, 1);
        SQLiteDatabase db=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String SQLString = "create table " + tableName + "("
                 + Col1 + " Integer Primary Key Autoincrement, "
                 + Col2 + " Text, "
                 + Col3 + " Text, "
                 + Col4 + " Text "
                 + ")" ;

     db.execSQL(SQLString);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists "+tableName);
        onCreate(db);
    }
}

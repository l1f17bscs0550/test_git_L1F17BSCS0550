package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class activity4 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity4);

        String patntnames[]={"ali", "zubda" };

      /*  SharedPreferences sharedpref1 = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        int num1=sharedpref1.getInt("count",0);
        for (int i = 0; i < num1; i++) {
        patntnames[i]=sharedpref1.getString("username"+i ,"");
        }
        */ListView myListView = findViewById(R.id.myList);

        ArrayAdapter myArrayAdapter = new customAdapter (this, patntnames);

        myListView.setAdapter(myArrayAdapter);

        //displaydoctor();
    }
    void displaydoctor()
    {
        SharedPreferences sharedpref1 = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        int num1=sharedpref1.getInt("count",0);


        for (int i = 0; i < num1; i++) {
            String na,e,a,h,g,t;
            int number;
            na=sharedpref1.getString("username"+i ,"");
            number=sharedpref1.getInt("myint"+i,0);
            e=sharedpref1.getString("Email"+i,"");
            h=sharedpref1.getString("Hospital"+i,"");
            a=sharedpref1.getString("Address"+i,"");
            t=sharedpref1.getString("Timing"+i,"");
            g=sharedpref1.getString("Gender"+i,"");

        }
    }


}

package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class activity9 extends AppCompatActivity {

    private RecyclerView myRecycleView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity9);

//recycleview
        myRecycleView =(RecyclerView) findViewById(R.id.recyclerView);
        myRecycleView.setHasFixedSize(true);
        myRecycleView.setLayoutManager(new LinearLayoutManager(this));

        listItems = new ArrayList<>();

        Bundle dataFromFirst=getIntent().getExtras();
        TextView mytext= findViewById(R.id.de);
        mytext.setText("");
        if(dataFromFirst==null)
        {
            return;
        }
        String n=dataFromFirst.getString("message");

        SharedPreferences sharedpref = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        int num=sharedpref.getInt("count",0);
        for (int i = 0; i < num; i++) {


            String rname = sharedpref.getString("username" + i, "");
            if (n.equals(rname)) {
                String na,e,a,h,g,t;
                int number;
                na=sharedpref.getString("username"+i ,"");
                number=sharedpref.getInt("myint"+i,0);
                e=sharedpref.getString("Email"+i,"");
                h=sharedpref.getString("Hospital"+i,"");
                a=sharedpref.getString("Address"+i,"");
                t=sharedpref.getString("Timing"+i,"");
                g=sharedpref.getString("Gender"+i,"");
                mytext.setText("Personal Information:-\nName : "+na+"\n"+"Number : "+number+"\n"+" Email : "+e+"\n"+"Hospital : "+h+"\n"+"Address : "+a+"\n"+"Timing : "+t+"\n"+"Gender :"+g+"\n");
                break;
            }
            displaypatient();
        }

    }
    void displaypatient()
    {
        SharedPreferences sharedpref1 = getSharedPreferences("patientinfo", Context.MODE_PRIVATE);
        int num1=sharedpref1.getInt("count",0);

        for (int i = 0; i < num1; i++) {
            String us,e,a,g;
            int n;
            us=sharedpref1.getString("username"+i ,"");
            e=sharedpref1.getString("Email"+i,"");
            a=sharedpref1.getString("Address"+i,"");
            g=sharedpref1.getString("Gender"+i,"");
            n=sharedpref1.getInt("myint"+i,0);

            ListItem listitem =new ListItem("Patient " + (i+1) + "\nName: " + us + "\nEmail: " + e + "\nAddress: " + a + "\nGender: " + g + "\nPhone Number: " + n + "\n");
            listItems.add(listitem);
        }
        adapter = new myadaptor (this,listItems);
        myRecycleView.setAdapter(adapter);
    }


}
